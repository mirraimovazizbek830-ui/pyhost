#!/bin/bash
echo "🚀 PyHost o'rnatilmoqda..."

# Docker o'rnatish
apt-get update -q
apt-get install -y docker.io docker-compose git

# Docker ishga tushirish
systemctl start docker
systemctl enable docker

# Loyiha papkasiga o'tish
cd /opt/pyhost

# Email sozlamalarini o'zgartiring!
echo ""
echo "⚠️  MUHIM: backend/docker-compose.yml faylida email sozlamalarini kiriting!"
echo "   SMTP_USER=sizning@gmail.com"
echo "   SMTP_PASS=gmail_app_password"
echo ""

# Build va ishga tushirish
docker-compose up -d --build

echo ""
echo "✅ PyHost ishga tushdi!"
echo "🌐 Sayt: http://$(curl -s ifconfig.me)"
echo "🔐 Admin: http://$(curl -s ifconfig.me)/#admin"
echo "   Admin parol: admin123"
echo ""
echo "⚠️  Admin parolini o'zgartiring: backend/main.py faylida ADMIN_PASSWORD"
